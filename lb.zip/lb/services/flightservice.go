package services

import "strings"

type Flight struct {
	ID          string `json:"id"`
	Origin      string `json:"origin"`
	Destination string `json:"destination"`
	Price       int    `json:"price"`
	Date        string `json:"date"`
}

// Mock database slice
var flightsDb = []Flight{
	{ID: "FL101", Origin: "NYC", Destination: "LON", Price: 450, Date: "2026-07-15"},
	{ID: "FL102", Origin: "NYC", Destination: "PAR", Price: 520, Date: "2026-07-16"},
	{ID: "FL103", Origin: "LAX", Destination: "TYO", Price: 890, Date: "2026-07-15"},
}

func SearchFlights(origin, destination string) []Flight {
	var results []Flight
	for _, f := range flightsDb {
		if strings.ToUpper(f.Origin) == strings.ToUpper(origin) &&
			strings.ToUpper(f.Destination) == strings.ToUpper(destination) {
			results = append(results, f)
		}
	}
	return results
}