package services

import (
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"strings"
	"time"
)

type BookingRequest struct {
	Passenger string `json:"passenger"`
	FlightID  string `json:"flightId"`
	Price     int    `json:"price"`
}

type BookingReceipt struct {
	Success          bool   `json:"success"`
	BookingReference string `json:"bookingReference"`
	Passenger        string `json:"passenger"`
	FlightID         string `json:"flightId"`
	AmountPaid       int    `json:"amountPaid"`
	Status           string `json:"status"`
	Timestamp        string `json:"timestamp"`
}

func CreateBooking(passenger, flightID string, price int) BookingReceipt {
	// Generate a short unique confirmation reference
	bytes := make([]byte, 3)
	_, _ = rand.Read(bytes)
	ref := fmt.Sprintf("BK-%s", strings.ToUpper(hex.EncodeToString(bytes)))

	return BookingReceipt{
		Success:          true,
		BookingReference: ref,
		Passenger:        passenger,
		FlightID:         flightID,
		AmountPaid:       price,
		Status:           "Confirmed",
		Timestamp:        time.Now().Format(time.RFC3339),
	}
}