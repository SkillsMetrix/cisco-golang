package main

import (
	"encoding/json"
	"lb/services"
	"fmt"
	"net/http"
	"os"
)

type APIResponse struct {
	Data               interface{} `json:"data"`
	HandledByContainer string      `json:"handledByContainer"`
}

func main() {
	serverName := os.Getenv("SERVER_NAME")
	if serverName == "" {
		serverName = "Unknown-Go-Node"
	}

	http.HandleFunc("/search", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
			return
		}
		var req struct {
			Origin      string `json:"origin"`
			Destination string `json:"destination"`
		}
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}

		results := services.SearchFlights(req.Origin, req.Destination)
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(APIResponse{Data: results, HandledByContainer: serverName})
	})

	http.HandleFunc("/booking", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
			return
		}
		var req services.BookingRequest
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}

		receipt := services.CreateBooking(req.Passenger, req.FlightID, req.Price)
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(APIResponse{Data: receipt, HandledByContainer: serverName})
	})

	fmt.Printf("%s up and running on internal port 3000...\n", serverName)
	if err := http.ListenAndServe(":3000", nil); err != nil {
		fmt.Printf("Server failed: %s\n", err)
	}
}