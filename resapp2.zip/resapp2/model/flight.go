package model

type Flight struct {
	ID    int  `json:"id"`
	FlightNo  string  `json:"flightNo"`
	Source string `json:"source"`
	Destination string `json:"destination"`
}

