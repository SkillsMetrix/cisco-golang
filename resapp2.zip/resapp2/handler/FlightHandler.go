package handler

import (
	"encoding/json"
	"flight-api/service"
	 
	"net/http"
	 
)
type FlightHandler struct {
	//DI
	svc service.FlightService
}
func NewFlightHandler(svc service.FlightService) *FlightHandler{
	return  &FlightHandler{svc: svc}
}

func(h *FlightHandler) GetFlights(w http.ResponseWriter,r *http.Request) {
	
	w.Header().Set("Content-Type", "application/json")
	flights := h.svc.FindAllFLights()
	json.NewEncoder(w).Encode(flights)
}