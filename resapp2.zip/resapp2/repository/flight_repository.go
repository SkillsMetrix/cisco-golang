package repository

import "flight-api/model"


type FlightRepository interface {
	GetAll() []model.Flight
	GetByID(id int)(model.Flight,bool)
	Create(flight model.Flight)model.Flight
	Update(id int, updatedFlight model.Flight)(model.Flight,bool)
	Delete(id int)bool
}