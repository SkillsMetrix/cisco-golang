package repository

import "flight-api/model"

type MemoryRepository struct {
	flights []model.Flight
}

func NewMemoryRepository() *MemoryRepository {
	return &MemoryRepository{
		flights: []model.Flight{
			{ID: 1, FlightNo: "A101", Source: "Mumbai", Destination: "Chennai"},
			{ID: 2, FlightNo: "SG01", Source: "Pune", Destination: "Delhi"},
		},
	}
}
func (r *MemoryRepository) GetAll() []model.Flight {
	return r.flights
}
func (r *MemoryRepository) GetByID(id int) (model.Flight, bool) {
	for _, flight := range r.flights {
		if flight.ID == id {
			return flight, true
		}
	}
	return model.Flight{}, false
}
func (r *MemoryRepository) Create(flight model.Flight) model.Flight {
	flight.ID = len(r.flights) + 1
	r.flights = append(r.flights, flight)
	return flight
}
func (r *MemoryRepository) Update(id int, updateFlight model.Flight) (model.Flight, bool) {

	for i, flight := range r.flights {
		if flight.ID == id {
			updateFlight.ID = id
			r.flights[i] = updateFlight

			return updateFlight, true
		}
	}
	return model.Flight{}, false

}
func (r *MemoryRepository) Delete(id int)  bool {
	for i, flight := range r.flights {
		if flight.ID == id {
			r.flights=append(r.flights[:i],r.flights[i+1:]... )

			return  true
		}
	}
	return false
}