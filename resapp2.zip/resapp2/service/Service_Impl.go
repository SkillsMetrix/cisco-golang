package service

import (
	"flight-api/model"
	"flight-api/repository"
)

type FlightServiceImpl struct {

	// DI inject Repo
	repo repository.FlightRepository
}
	func NewFlightService(repo repository.FlightRepository) *FlightServiceImpl{
		return  &FlightServiceImpl{repo: repo}
	}

	func(s * FlightServiceImpl)FindAllFLights() []model.Flight{
		return  s.repo.GetAll()
	}