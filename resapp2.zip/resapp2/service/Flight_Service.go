
package service

import "flight-api/model"


type FlightService interface {
	FindAllFLights() []model.Flight
	
}