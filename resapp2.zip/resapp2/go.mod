module flight-api

go 1.26.4
