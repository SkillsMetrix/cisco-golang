package main

import (
	"flight-api/handler"
	"flight-api/repository"
	"flight-api/service"
	"net/http"
)

func main() {
	//inject DL

	repo := repository.NewMemoryRepository()

	svc := service.NewFlightService(repo)

	flightHanlder := handler.NewFlightHandler(svc)

	http.HandleFunc("/flights", func(w http.ResponseWriter, r *http.Request) {
		switch r.Method {
		case http.MethodGet:
			flightHanlder.GetFlights(w, r)
		default:
			http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		}

	})
	println("Server started")
	http.ListenAndServe(":8080", nil)

}
