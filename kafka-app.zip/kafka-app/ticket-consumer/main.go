package main

import (
	"context"
	"log"
	"time"

	"github.com/IBM/sarama"
)

const (
	kafkaTopic    = "flight-tickets"
	consumerGroup = "ticket-printing-group"
)

func main() {
	config := sarama.NewConfig()
	config.Consumer.Offsets.Initial = sarama.OffsetOldest

	var group sarama.ConsumerGroup
	var err error

	// Retry connection loop
	for i := 1; i <= 5; i++ {
		log.Printf("Connecting to Kafka (Attempt %d/5)...", i)
		group, err = sarama.NewConsumerGroup([]string{"kafka:9092"}, consumerGroup, config)
		if err == nil {
			break
		}
		log.Printf("Kafka not ready yet: %v. Retrying in 3 seconds...", err)
		time.Sleep(3 * time.Second)
	}

	if err != nil {
		log.Fatalf("Failed to start consumer group after retries: %v", err)
	}
	defer group.Close()

	handler := TicketHandler{}
	ctx := context.Background()

	log.Println("Ticket Processing Service is running and waiting for bookings...")
	for {
		err := group.Consume(ctx, []string{kafkaTopic}, &handler)
		if err != nil {
			log.Printf("Error during consumption: %v\n", err)
			time.Sleep(2 * time.Second) // Prevent tight loop on error
		}
	}
}

type TicketHandler struct{}

func (TicketHandler) Setup(_ sarama.ConsumerGroupSession) error   { return nil }
func (TicketHandler) Cleanup(_ sarama.ConsumerGroupSession) error { return nil }

func (TicketHandler) ConsumeClaim(session sarama.ConsumerGroupSession, claim sarama.ConsumerGroupClaim) error {
	for msg := range claim.Messages() {
		log.Printf("\n========================================\n"+
			"🚨 NEW TICKET ISSUED 🚨\n"+
			"Data: %s\n"+
			"Partition: %d | Offset: %d\n"+
			"========================================\n",
			string(msg.Value), msg.Partition, msg.Offset)

		session.MarkMessage(msg, "")
	}
	return nil
}