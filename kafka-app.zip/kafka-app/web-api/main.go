package main

import (
	"database/sql"
	"encoding/json"
	"log"
	"net/http"
	"time"

	"github.com/IBM/sarama"
	"github.com/gin-gonic/gin"
	_ "github.com/mattn/go-sqlite3"
)

type Booking struct {
	ID        int64  `json:"id"`
	Passenger string `json:"passenger" binding:"required"`
	FlightNum string `json:"flight_number" binding:"required"`
}

var (
	db       *sql.DB
	producer sarama.SyncProducer
)

const kafkaTopic = "flight-tickets"

func main() {
	var err error

	// 1. Setup SQLite
	db, err = sql.Open("sqlite3", "./bookings.db")
	if err != nil {
		log.Fatalf("DB connection failed: %v", err)
	}
	defer db.Close()

	_, err = db.Exec(`CREATE TABLE IF NOT EXISTS bookings (id INTEGER PRIMARY KEY AUTOINCREMENT, passenger TEXT, flight_num TEXT);`)
	if err != nil {
		log.Fatalf("Table creation failed: %v", err)
	}


	config := sarama.NewConfig()
	config.Producer.Return.Successes = true

	for i := 1; i <= 5; i++ {
		log.Printf("Connecting to Kafka Producer (Attempt %d/5)...", i)
		producer, err = sarama.NewSyncProducer([]string{"kafka:9092"}, config)
		if err == nil {
			log.Println("✅ Kafka Producer successfully connected!")
			break
		}
		log.Printf("⚠️ Kafka Producer not ready: %v. Retrying in 3 seconds...", err)
		time.Sleep(3 * time.Second)
	}

	if err != nil {
		log.Fatalf("❌ Kafka producer failed completely after retries: %v", err)
	}
	defer producer.Close()

	// 3. Setup Gin Router
	r := gin.Default()
	r.POST("/book", handleBooking)

	log.Println(" Flight API engine started on port 8080...")
	r.Run(":8080")
}

func handleBooking(c *gin.Context) {
	var b Booking
	if err := c.ShouldBindJSON(&b); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	 
	res, err := db.Exec("INSERT INTO bookings (passenger, flight_num) VALUES (?, ?)", b.Passenger, b.FlightNum)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to save booking to database"})
		return
	}

	b.ID, _ = res.LastInsertId()

	
	payload, err := json.Marshal(b)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to process ticket payload"})
		return
	}

	// Send Ticket to Kafka Topic
	msg := &sarama.ProducerMessage{
		Topic: kafkaTopic,
		Value: sarama.StringEncoder(payload),
	}
	_, _, err = producer.SendMessage(msg)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "Failed to issue ticket to event stream"})
		return
	}

	c.JSON(http.StatusOK, gin.H{
		"status":  "Flight booked successfully!",
		"booking": b,
	})
}