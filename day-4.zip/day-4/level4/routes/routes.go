package routes

import (
	"go-gin-mysql-app/controllers"

	"github.com/gin-gonic/gin"
)

func SetupRoutes(router *gin.Engine){
	router.GET("/users",controllers.GetUser)
	router.POST("/users",controllers.CreateUser)
}
