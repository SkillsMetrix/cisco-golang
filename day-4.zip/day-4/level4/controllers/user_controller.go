package controllers

import (
	"go-gin-mysql-app/config"
	"go-gin-mysql-app/models"
	"net/http"

	"github.com/gin-gonic/gin"
)

func CreateUser(c *gin.Context) {

	var user models.User

	if err := c.ShouldBindJSON(&user); err != nil {

		c.JSON(http.StatusBadRequest, gin.H{
			"error": err.Error(),
		})
		return
	}
	config.DB.Create(&user)
	c.JSON(http.StatusCreated, user)
}
func GetUser(c *gin.Context) {
	var users []models.User

	config.DB.Find(&users)

c.JSON(http.StatusOK, users)
}
