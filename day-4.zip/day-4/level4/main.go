package main

import (
	"fmt"
	"go-gin-mysql-app/config"
	"go-gin-mysql-app/models"
	"go-gin-mysql-app/routes"
	"log"
	"os"

	"github.com/gin-gonic/gin"
	"github.com/joho/godotenv"
)

func main() {
	err := godotenv.Load()
	fmt.Println(os.Getenv("DB_HOST"))
	fmt.Println(os.Getenv("DB_HOST"))
	fmt.Println(os.Getenv("DB_HOST"))
	fmt.Println(os.Getenv("DB_HOST"))

	if err != nil {
		log.Println(".env file not found")
	}

	config.ConnectDatabase()
	config.DB.AutoMigrate(&models.User{})
	router := gin.Default()
	routes.SetupRoutes(router)
	router.Run(":8080")
}
