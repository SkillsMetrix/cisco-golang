package main

import "fmt"

func main(){
	fmt.Println("Addition Demo begins......!")

	a:=21
	b:=34
	fmt.Printf("Sum = %d\n", a+b)
}