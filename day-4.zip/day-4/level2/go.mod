module go-docker-module

go 1.26.4
